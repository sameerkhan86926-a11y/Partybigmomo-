// app.js - minimal demo: camera capture -> OpenCV auto-crop -> filter -> pdf-lib export
const video = document.getElementById('video');
const overlay = document.getElementById('overlay');
const captureBtn = document.getElementById('captureBtn');
const addPageBtn = document.getElementById('addPageBtn');
const downloadPdfBtn = document.getElementById('downloadPdfBtn');
const filterSelect = document.getElementById('filter');
const previewArea = document.getElementById('previewArea');
const pagesCount = document.getElementById('pagesCount');

let pages = []; // store dataURLs of processed pages

// start camera
async function startCamera(){
  try{
    const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
    video.srcObject = stream;
    await video.play();
    resizeOverlay();
  } catch(e){
    alert('Camera access error: ' + e.message);
  }
}
function resizeOverlay(){
  overlay.width = video.clientWidth;
  overlay.height = video.clientHeight;
}

window.addEventListener('resize', resizeOverlay);
startCamera();

// wait for OpenCV to be ready
function whenCvReady(fn){
  if (typeof cv !== 'undefined' && cv && cv.Mat) return fn();
  console.log('Waiting for OpenCV...');
  const id = setInterval(()=>{
    if (typeof cv !== 'undefined' && cv && cv.Mat){
      clearInterval(id);
      fn();
    }
  }, 100);
}

// capture frame to canvas
function captureFrame(){
  const tmp = document.createElement('canvas');
  tmp.width = video.videoWidth;
  tmp.height = video.videoHeight;
  const ctx = tmp.getContext('2d');
  ctx.drawImage(video, 0, 0, tmp.width, tmp.height);
  return tmp;
}

// draw polygon overlay (for debug)
function drawOverlay(pts){
  const ctx = overlay.getContext('2d');
  ctx.clearRect(0,0,overlay.width,overlay.height);
  if(!pts) return;
  ctx.strokeStyle = 'lime';
  ctx.lineWidth = 3;
  ctx.beginPath();
  for(let i=0;i<pts.length;i++){
    const p = pts[i];
    const x = p.x * overlay.width / video.videoWidth;
    const y = p.y * overlay.height / video.videoHeight;
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  }
  ctx.closePath();
  ctx.stroke();
}

// basic document detection + perspective transform using OpenCV.js
function detectAndCrop(inputCanvas){
  // inputCanvas: DOM canvas with full resolution image
  const src = cv.imread(inputCanvas);
  const origH = src.rows, origW = src.cols;

  // convert to gray, blur, edge
  const gray = new cv.Mat();
  cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY, 0);
  const blurred = new cv.Mat();
  cv.GaussianBlur(gray, blurred, new cv.Size(5,5), 0);
  const edges = new cv.Mat();
  cv.Canny(blurred, edges, 75, 200);

  // find contours
  const contours = new cv.MatVector();
  const hierarchy = new cv.Mat();
  cv.findContours(edges, contours, hierarchy, cv.RETR_LIST, cv.CHAIN_APPROX_SIMPLE);

  let maxArea = 0;
  let bestContour = null;
  for(let i=0;i<contours.size();i++){
    const cnt = contours.get(i);
    const area = cv.contourArea(cnt);
    if(area < 1000) { cnt.delete(); continue; }
    const peri = cv.arcLength(cnt, true);
    const approx = new cv.Mat();
    cv.approxPolyDP(cnt, approx, 0.02 * peri, true);
    if (approx.rows === 4 && area > maxArea){
      maxArea = area;
      if (bestContour) bestContour.delete();
      bestContour = approx;
    } else {
      approx.delete();
    }
    cnt.delete();
  }

  let resultCanvas = document.createElement('canvas');
  if (bestContour){
    // get 4 points
    const pts = [];
    for(let i=0;i<4;i++){
      pts.push({ x: bestContour.intPtr(i,0)[0], y: bestContour.intPtr(i,0)[1] });
    }
    // Order points: top-left, top-right, bottom-right, bottom-left
    // simple ordering using sum/diff
    pts.sort((a,b)=> (a.x + a.y) - (b.x + b.y)); // tl has smallest sum
    const tl = pts[0];
    const br = pts[3];
    const others = [pts[1], pts[2]];
    let tr = others[0], bl = others[1];
    if (tr.x < bl.x) [tr, bl] = [bl, tr];

    const srcTri = cv.matFromArray(4,1,cv.CV_32FC2, [tl.x, tl.y, tr.x, tr.y, br.x, br.y, bl.x, bl.y]);

    // compute width/height of new image
    const widthA = Math.hypot(br.x - bl.x, br.y - bl.y);
    const widthB = Math.hypot(tr.x - tl.x, tr.y - tl.y);
    const maxWidth = Math.max(Math.round(widthA), Math.round(widthB));
    const heightA = Math.hypot(tr.x - br.x, tr.y - br.y);
    const heightB = Math.hypot(tl.x - bl.x, tl.y - bl.y);
    const maxHeight = Math.max(Math.round(heightA), Math.round(heightB));

    const dstTri = cv.matFromArray(4,1,cv.CV_32FC2, [0,0, maxWidth-1,0, maxWidth-1, maxHeight-1, 0, maxHeight-1]);
    const M = cv.getPerspectiveTransform(srcTri, dstTri);
    const dst = new cv.Mat();
    cv.warpPerspective(src, dst, M, new cv.Size(maxWidth, maxHeight), cv.INTER_LINEAR, cv.BORDER_CONSTANT, new cv.Scalar());

    // show overlay (scaled)
    drawOverlay([tl, tr, br, bl]);

    // convert dst to canvas
    resultCanvas.width = dst.cols;
    resultCanvas.height = dst.rows;
    cv.imshow(resultCanvas, dst);

    // cleanup
    dst.delete(); M.delete(); srcTri.delete(); dstTri.delete(); bestContour.delete();
  } else {
    // fallback: return original
    resultCanvas.width = inputCanvas.width;
    resultCanvas.height = inputCanvas.height;
    const ctx = resultCanvas.getContext('2d');
    ctx.drawImage(inputCanvas,0,0);
    drawOverlay(null);
  }

  // cleanup mats
  src.delete(); gray.delete(); blurred.delete(); edges.delete(); contours.delete(); hierarchy.delete();

  return resultCanvas;
}

// image filters
function applyFilter(canvas, mode){
  if(mode==='none') return canvas;
  const tmp = document.createElement('canvas');
  tmp.width = canvas.width; tmp.height = canvas.height;
  const ctx = tmp.getContext('2d');
  ctx.drawImage(canvas,0,0);
  const imgData = ctx.getImageData(0,0,tmp.width,tmp.height);
  const d = imgData.data;
  if(mode==='gray' || mode==='bw' || mode==='enhance'){
    // simple grayscale then maybe contrast
    for(let i=0;i<d.length;i+=4){
      const r=d[i], g=d[i+1], b=d[i+2];
      let v = 0.299*r + 0.587*g + 0.114*b;
      if(mode==='bw'){
        v = v>128?255:0;
      }
      d[i]=d[i+1]=d[i+2]=v;
    }
    if(mode==='enhance'){
      // contrast boost (simple)
      const factor = (259*(128+50))/(255*(259-50));
      for(let i=0;i<d.length;i+=4){
        d[i] = truncate(factor*(d[i]-128)+128);
        d[i+1] = truncate(factor*(d[i+1]-128)+128);
        d[i+2] = truncate(factor*(d[i+2]-128)+128);
      }
    }
    ctx.putImageData(imgData,0,0);
  }
  return tmp;
}
function truncate(v){ return Math.max(0, Math.min(255, v)); }

// add preview thumbnail
function addPreview(dataUrl){
  const img = document.createElement('img');
  img.src = dataUrl;
  img.className = 'preview-img';
  previewArea.appendChild(img);
  pages.push(dataUrl);
  pagesCount.textContent = `Pages: ${pages.length}`;
  addPageBtn.disabled = false;
  downloadPdfBtn.disabled = pages.length===0;
}

// create PDF from pages (dataURLs) using pdf-lib
async function createPdfAndDownload(){
  const { PDFDocument } = PDFLib;
  const pdfDoc = await PDFDocument.create();
  for(const durl of pages){
    const isPng = durl.startsWith('data:image/png');
    const imgBytes = await (await fetch(durl)).arrayBuffer();
    let img;
    if(isPng) img = await pdfDoc.embedPng(imgBytes);
    else img = await pdfDoc.embedJpg(imgBytes);
    const page = pdfDoc.addPage([img.width, img.height]);
    page.drawImage(img, { x:0, y:0, width: img.width, height: img.height });
  }
  const pdfBytes = await pdfDoc.save();
  const blob = new Blob([pdfBytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'document.pdf'; a.click();
  URL.revokeObjectURL(url);
}

// event wiring
captureBtn.addEventListener('click', async ()=>{
  const canvas = captureFrame();
  whenCvReady(()=> {
    const cropped = detectAndCrop(canvas);
    const filtered = applyFilter(cropped, filterSelect.value);
    // show large preview
    const dataUrl = filtered.toDataURL('image/jpeg', 0.9);
    const big = document.createElement('img');
    big.src = dataUrl;
    big.style.maxWidth = '120px';
    addPreview(dataUrl);
  });
});

addPageBtn.addEventListener('click', ()=>{
  // already added on capture; button can be repurposed to clear?
});

downloadPdfBtn.addEventListener('click', createPdfAndDownload);

// enable/disable add btn whenever pages updated
const obs = new MutationObserver(()=> {
  downloadPdfBtn.disabled = pages.length===0;
  addPageBtn.disabled = pages.length===0;
});
obs.observe(previewArea, { childList: true });